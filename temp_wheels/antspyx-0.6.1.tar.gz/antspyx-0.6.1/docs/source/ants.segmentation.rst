ants.segmentation package
=========================

Submodules
----------

ants.segmentation.anti\_alias module
------------------------------------

.. automodule:: ants.segmentation.anti_alias
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.atropos module
--------------------------------

.. automodule:: ants.segmentation.atropos
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.joint\_label\_fusion module
---------------------------------------------

.. automodule:: ants.segmentation.joint_label_fusion
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.kelly\_kapowski module
----------------------------------------

.. automodule:: ants.segmentation.kelly_kapowski
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.kmeans module
-------------------------------

.. automodule:: ants.segmentation.kmeans
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.label\_geometry\_measures module
--------------------------------------------------

.. automodule:: ants.segmentation.label_geometry_measures
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.otsu module
-----------------------------

.. automodule:: ants.segmentation.otsu
   :members:
   :undoc-members:
   :show-inheritance:

ants.segmentation.prior\_based\_segmentation module
---------------------------------------------------

.. automodule:: ants.segmentation.prior_based_segmentation
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: ants.segmentation
   :members:
   :undoc-members:
   :show-inheritance:
