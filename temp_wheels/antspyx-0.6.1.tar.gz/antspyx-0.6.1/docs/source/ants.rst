ants package
============

Subpackages
-----------

.. toctree::

   ants.core
   ants.learn
   ants.lib
   ants.registration
   ants.segmentation
   ants.utils
   ants.viz

Submodules
----------

ants.version module
-------------------

.. automodule:: ants.version
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: ants
   :members:
   :undoc-members:
   :show-inheritance:
