Deeplearn
===================================
.. automodule:: ants

.. autofunction:: extract_image_patches
.. autofunction:: reconstruct_image_from_patches
.. autofunction:: regression_match_image
.. autofunction:: crop_image_center
.. autofunction:: pad_or_crop_image_to_size
.. autofunction:: pad_image_by_factor
.. autofunction:: histogram_warp_image_intensities
.. autofunction:: simulate_bias_field
.. autofunction:: randomly_transform_image_data 
.. autofunction:: data_augmentation
