Statistical Learning
===================================
.. automodule:: ants

.. autofunction:: sparse_decom2
.. autofunction:: eig_seg
.. autofunction:: initialize_eigenanatomy
