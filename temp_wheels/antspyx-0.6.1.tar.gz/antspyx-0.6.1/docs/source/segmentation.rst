Segmentation
===================================
.. automodule:: ants

.. autofunction:: atropos
.. autofunction:: joint_label_fusion
.. autofunction:: kelly_kapowski
.. autofunction:: kmeans_segmentation
.. autofunction:: fuzzy_spatial_cmeans_segmentation
.. autofunction:: label_geometry_measures
.. autofunction:: prior_based_segmentation
