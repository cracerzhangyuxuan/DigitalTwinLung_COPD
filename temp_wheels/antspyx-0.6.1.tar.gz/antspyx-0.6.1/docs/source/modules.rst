ANTsPy
======

.. toctree::
   :maxdepth: 4

   ants
   setup
