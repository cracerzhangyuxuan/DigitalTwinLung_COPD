Registration
===================================
.. automodule:: ants

.. autofunction:: registration
.. autofunction:: affine_initializer
.. autofunction:: apply_transforms
.. autofunction:: create_jacobian_determinant_image
.. autofunction:: create_warped_grid
.. autofunction:: fsl2antstransform
.. autofunction:: image_mutual_information
.. autofunction:: reflect_image
.. autofunction:: reorient_image
.. autofunction:: get_center_of_mass
.. autofunction:: resample_image
.. autofunction:: resample_image_to_target
