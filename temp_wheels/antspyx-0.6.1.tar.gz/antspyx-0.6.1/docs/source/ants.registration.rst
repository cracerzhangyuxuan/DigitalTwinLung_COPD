ants.registration package
=========================

Submodules
----------

ants.registration.affine\_initializer module
--------------------------------------------

.. automodule:: ants.registration.affine_initializer
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.apply\_transforms module
------------------------------------------

.. automodule:: ants.registration.apply_transforms
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.build\_template module
----------------------------------------

.. automodule:: ants.registration.build_template
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.create\_jacobian\_determinant\_image module
-------------------------------------------------------------

.. automodule:: ants.registration.create_jacobian_determinant_image
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.create\_warped\_grid module
---------------------------------------------

.. automodule:: ants.registration.create_warped_grid
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.fsl2antstransform module
------------------------------------------

.. automodule:: ants.registration.fsl2antstransform
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.interface module
----------------------------------

.. automodule:: ants.registration.interface
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.make\_points\_image module
--------------------------------------------

.. automodule:: ants.registration.make_points_image
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.metrics module
--------------------------------

.. automodule:: ants.registration.metrics
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.reflect\_image module
---------------------------------------

.. automodule:: ants.registration.reflect_image
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.reorient\_image module
----------------------------------------

.. automodule:: ants.registration.reorient_image
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.resample\_image module
----------------------------------------

.. automodule:: ants.registration.resample_image
   :members:
   :undoc-members:
   :show-inheritance:

ants.registration.symmetrize\_image module
------------------------------------------

.. automodule:: ants.registration.symmetrize_image
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: ants.registration
   :members:
   :undoc-members:
   :show-inheritance:
