
from .decomposition import (eig_seg,
                            initialize_eigenanatomy,
                            sparse_decom2)