
see also [a notebook example with functional MRI (fMRI) data from the human connectome project (HCP)](https://github.com/stnava/structuralFunctionalJointRegistration/blob/master/src/Default%20Mode%20Connectivity%20in%20ANTsPy.ipynb)
